# Automatic name detection (GLiNER)

`prosze_proxy.py` now supports model-based name detection without a manually maintained name list.
The GLiNER model runs locally; prompt text is not sent to a remote inference API. On the first use,
GLiNER downloads `urchade/gliner_small-v2.1` from Hugging Face and caches it for later runs.

## Install

```powershell
python -m pip install -r requirements-ner.txt
```

## Use

```powershell
Get-Content .\prompt.txt | python .\prosze_proxy.py redact
```

The first run may take longer while the model is downloaded and initialized. Detected names are
replaced with placeholders such as `[[PERSON_1]]`; the existing `.prosze-map` supports restoration.
The model recognizes likely people, organizations, companies, customers, and projects, but it is
not perfect. Review results before sending sensitive text to an external service.

To turn model-based recognition off for a command, pass `--no-ner`:

```powershell
Get-Content .\prompt.txt | python .\prosze_proxy.py redact --no-ner
```

## Notes

- Existing regex detection and explicit `--term` / `--terms` behavior remain available.
- The standalone C++ `prosze.cpp` continues to use its built-in heuristic detector; this GLiNER
  integration is in the Python CLI/proxy path.
- Keep `.prosze-map` private because it contains original values.
